import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import "../App.css";

export default function CategoryPage() {
  const { category } = useParams(); // Get category from URL
  const [products, setProducts] = useState([]);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch(
          `https://fakestoreapi.com/products/category/${category}`
        );
        const data = await res.json();
        setProducts(data.slice(0, 8)); // limit to 8 products
      } catch (err) {
        console.error(err);
      }
    }
    load();
  }, [category]);

  return (
    <div style={{ padding: "50px" }}>
      <h1 className="category-heading">{category}</h1>

      <div className="product-grid">
        {products.map((p) => (
          <Link
            key={p.id}
            to={`/product/${p.id}`}
            className="product-card"
          >
            <img src={p.image} alt={p.title} />
            <h2>{p.title}</h2>
            <p>Price: LKR{p.price}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
