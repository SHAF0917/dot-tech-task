import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "../App.css";

export default function Home() {
  const [latest, setLatest] = useState([]);

  useEffect(() => {
    async function load() {
      try {
  // fetch products
  const prodRes = await fetch("https://fakestoreapi.com/products");
  const prods = await prodRes.json();
  setLatest(prods.slice(0, 8)); // first 8 products

      } catch (err) {
        console.error(err);
      }
    }
    load();
  }, []);

  return (
    <div className="home-container">
      {/* Banner Section */}
      <div className="banner">
        <h1>Welcome  My Online Shop!</h1>
        <p>Discover the best products and deals every day.</p>
        
      </div>

      {/* Flash Sale Section */}
      <section className="flash-sale">
        <h1>Flash Sale</h1>
       <div className="category-tiles" style={{ display: 'flex', gap: '10px',  }}>
          {latest.slice(0, 2).map((p) => (
            <Link
              key={p.id}
              to={"/product/" + p.id}
              className="category-tile"
              style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', textDecoration: 'none' }}
            >
              <h2><span>{p.category}</span></h2>
              <img src={p.image} alt={p.title} style={{ width: '100px', margin: '10px 0' }} />
              <h3>{p.title}</h3>
              <p>Price: LKR{p.price}</p>
            </Link>
          ))}
        </div>
      </section>


      {/* Categories */}
      <section>
        <h2><center>Shop by Category</center></h2>
        <ul className="categories-list">
    <li>
      <Link to={`/category/${encodeURIComponent("men's clothing")}`}
  style={{ textDecoration: 'none', color: 'black' }}>
 <h2>Men's Clothing</h2> 
</Link>

    </li>
    <li>
      <Link to={`/category/${encodeURIComponent("women's clothing")}`}
      style={{ textDecoration: 'none', color: 'black' }}>
        <h2>Women's Clothing</h2>
      </Link>
    </li>
  </ul>
      </section>
    </div>
  );
}