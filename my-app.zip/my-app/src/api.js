// Example API helper file
export async function getProducts() {
  const res = await fetch("http://localhost:5000/products");
  return res.json();
}

export async function getCategories() {
  const res = await fetch("http://localhost:5000/categories");
  return res.json();
}